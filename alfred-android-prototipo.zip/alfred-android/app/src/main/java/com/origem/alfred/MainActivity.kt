package com.origem.alfred

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 24, 32)
    private val panel = Color.rgb(28, 39, 49)
    private val mint = Color.rgb(110, 231, 183)
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(16))
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "ALFRED"
            textSize = 28f
            setTextColor(mint)
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "PROJETO ORIGEM  •  PROTÓTIPO 0.1"
            textSize = 11f
            setTextColor(Color.LTGRAY)
        }
        root.addView(title)
        root.addView(subtitle)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setPadding(0, dp(20), 0, dp(12))
        }
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addMessage("Alfred", "Olá. Sou o primeiro protótipo do Alfred. Ainda estou em construção, mas podemos começar organizando ideias, tarefas e próximos passos.", false)

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Escreva uma ideia ou tarefa..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(panel)
            minHeight = dp(48)
        }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        val send = Button(this).apply {
            text = "Enviar"
            setTextColor(bg)
            setBackgroundColor(mint)
            setOnClickListener { sendMessage() }
        }
        composer.addView(send, LinearLayout.LayoutParams(-2, dp(48)).apply { leftMargin = dp(8) })
        root.addView(composer)
        setContentView(root)
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        addMessage("Você", text, true)
        input.setText("")
        addMessage("Alfred", "Recebi sua mensagem. Neste protótipo, a conversa ainda não está conectada a uma inteligência artificial. O próximo passo será adicionar essa conexão com segurança.", false)
    }

    private fun addMessage(who: String, body: String, fromUser: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(if (fromUser) Color.rgb(35, 57, 55) else panel)
        }
        val name = TextView(this).apply {
            text = who
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (fromUser) mint else Color.LTGRAY)
        }
        val content = TextView(this).apply {
            text = body
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, dp(5), 0, 0)
        }
        card.addView(name)
        card.addView(content)
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        messages.addView(card, params)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
