# Alfred — Projeto Origem (protótipo 0.1)

Este é um protótipo Android inicial para testar a instalação e a interface do Alfred.

## O que já faz
- Abre uma tela inicial do Alfred.
- Permite digitar mensagens e exibe respostas demonstrativas.
- Inclui um fluxo do GitHub Actions para gerar um APK de depuração na nuvem.

## Limitações desta versão
- Ainda não está conectado a um modelo de IA.
- Não salva conversas nem cria lembretes reais.
- É um primeiro protótipo de interface, não o Alfred completo.

## Gerar APK
Envie os arquivos do projeto ao repositório GitHub. Depois abra **Actions**, selecione **Build Alfred APK** e toque em **Run workflow** (ou faça um commit na branch principal). Ao terminar, baixe o artefato `alfred-debug-apk` e extraia o APK.
